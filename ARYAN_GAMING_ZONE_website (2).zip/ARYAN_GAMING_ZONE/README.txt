ARYAN GAMING ZONE

Included:
- Responsive dark neon gaming homepage
- Search and category filters
- Six original playable browser mini-games: Neon Snake, Tic Tac Toe, Memory Match, Click Rush, Rock Paper Scissors, Number Guess
- No installation required for players

Run locally:
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, or Firefox.

Publish free:
- Create a GitHub account and a new public repository.
- Upload index.html.
- In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
- GitHub Pages will provide a public website address.

About 500+ games:
This starter contains six playable original games, not 500. To publish a genuine 500+ library, add games you own or have permission to embed/distribute, or integrate a licensed HTML5 game provider. Do not copy games from other sites without permission.
